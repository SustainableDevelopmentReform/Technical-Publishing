# Acknowledgements

Report for Digital Finance Cooperative Research Centre.

Weblink for rendered outputs: https://sustainabledevelopmentreform.github.io/ImpactExchangeMetrics/ 

[![DOI](https://zenodo.org/badge/912787851.svg)](https://doi.org/10.5281/zenodo.14607743)
